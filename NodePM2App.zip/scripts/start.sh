#!/bin/bash
cd /home/ec2-user/NodeJS-PM2-CICD
pm2 start ecosystem.config.js

