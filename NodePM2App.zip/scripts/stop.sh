#!/bin/bash
pm2 stop all || true

