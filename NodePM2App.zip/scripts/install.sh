#!/bin/bash
cd /home/ec2-user/NodePM2App
npm install

